# Deadline Desk — Academic Task Planner

A responsive task planner starter with:
- Add, edit, delete, and mark tasks done
- Required deadline date and time
- Open / due today / overdue / completed counters
- Search, filters, deadline sorting, and upcoming deadline list
- Browser notifications and spoken reminders (while the page is open)
- Local preview mode without a backend
- Supabase database + Realtime sync when configured

## 1. Preview locally
Open `index.html` in a modern browser. In preview mode, tasks are stored in that browser's local storage only. This is not yet online or shared.

## 2. Enable online database and realtime sync
1. Create a project at https://supabase.com/
2. Open **SQL Editor** in your project and run all SQL in `supabase.sql`.
3. In Supabase project settings, find the **Project URL** and the **anon/public key**.
4. In `index.html`, replace the empty values near the top of the script:
   ```js
   const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
   const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";
   ```
   Use only the anon/public key in browser code. Never expose a service-role key.
5. Deploy `index.html` as a static site using a host such as Netlify, Vercel, or GitHub Pages. Upload the HTML file (and keep the project URL/key configured). HTTPS is recommended and generally required for browser notifications.
6. Open the deployed URL on each device. Realtime task changes should appear for everyone connected to this same project.

## Important privacy note
The included SQL policies make a shared demo workspace: anyone with the website URL and public anon key can read, add, change, or delete tasks. This is suitable only for a non-sensitive demo. For a real class/team deployment, use Supabase Auth (sign-in) and restrictive row-level security so only approved users can access your workspace. Do not put private student details or confidential information in the demo.

## Reminder limitations
- Browser notifications require permission.
- Voice reminders use the browser's speech synthesis and are device/browser dependent.
- The page must remain open for reminders to fire; browser throttling, sleeping devices, and closed tabs can delay or prevent reminders.
- This starter does not send server-side reminders while the website is closed. For reliable email/push alerts, add a scheduled backend function and a notification provider.
- Deadline timestamps use the browser's local timezone.

## Before real use
Test with a disposable task first. Check the browser permission prompt, voice test, and two-device realtime sync. If you want a private group with logins, add authentication and per-user/team permissions before sharing the URL.
